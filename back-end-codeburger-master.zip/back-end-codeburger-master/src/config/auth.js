export default {
  secret: '6521892f4ffd14e87ab89fad8e1c53d6',
  expiresIn: '3d',
}
